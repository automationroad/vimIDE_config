## About

Deol.nvim is a dark powered shell for Neovim.
It is based on neovim or Vim terminal feature.

## Requirements

deol requires Neovim or terminal feature enabled Vim.
