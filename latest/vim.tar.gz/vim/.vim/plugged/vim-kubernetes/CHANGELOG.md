v1.2.0

- Add async option for those on vim 8+

v1.1.0

- Added commands for KubeDelete, KubeCreate, and directory-specific variants *Dir
- vim-kubernetes commands and code should now only load for yaml files
